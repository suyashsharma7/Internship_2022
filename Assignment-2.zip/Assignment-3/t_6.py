def average(array):
    # your code goes here
    l = list(set(array))
    return sum(l)/len(l)

if __name__ == '__main__':